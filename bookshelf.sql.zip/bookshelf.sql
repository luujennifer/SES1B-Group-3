-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 27, 2020 at 06:32 AM
-- Server version: 8.0.21
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookshelf`
--
CREATE DATABASE IF NOT EXISTS `bookshelf` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `bookshelf`;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int NOT NULL,
  `author` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `publisher` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_of_publication` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_publication` date NOT NULL,
  `ISBN` int NOT NULL,
  `type` enum('Fiction','Non-Fiction') COLLATE utf8mb4_unicode_ci NOT NULL,
  `non_fiction_topic` enum('Architecture','Built Environment','Business','Communication','Design','Education','Engineering','Health','Indigenous Studies','Information Technology','International Studies','Law','News','Science','Not Applicable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiction_topic` enum('Modern & Contemporary Fiction','Poetry & Drama','Romance','Crime','Classic Fiction','Fantasy','Adventure Fiction','Science Fiction','Historical Fiction','Horror & Paranormal Fiction','Graphic Novels','Young Adult','Manga','Dystopian','Picture Book','Not Applicable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` enum('E-Book','Hard Copy') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `copies` int NOT NULL,
  `available` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `author`, `title`, `publisher`, `place_of_publication`, `date_of_publication`, `ISBN`, `type`, `non_fiction_topic`, `fiction_topic`, `format`, `copies`, `available`) VALUES
(1, 'Joy Lee', 'Book 1', 'Group 3', 'Australia', '2020-09-22', 1234567890, 'Non-Fiction', 'Engineering', 'Not Applicable', 'E-Book', 2, 1),
(2, 'James Smith', 'Book 2', 'Magic', 'USA', '2020-09-04', 987654321, 'Non-Fiction', 'Science', 'Not Applicable', 'E-Book', 1, 1),
(3, 'John Jonah Jameson Jr.', 'Book 3', 'Publisher.Inc', 'Russia', '2020-05-14', 234516789, 'Non-Fiction', 'International Studies', 'Not Applicable', 'E-Book', 1, 1),
(4, 'Mathew Reilly', 'Scarecrow', 'St. Martin\'s Paperback', 'USA', '2003-10-03', 978031293, 'Fiction', 'Not Applicable', 'Crime', 'Hard Copy', 3, 3),
(5, 'James Dashner', 'The Fever Code', 'Chicken House', 'USA', '2016-09-27', 978191107, 'Fiction', 'Not Applicable', 'Young Adult', 'Hard Copy', 1, 1),
(6, 'Judy Kay, Bob Kummerfeld', 'C Programming in a Unix Environment', 'Addison Wesley', 'United Kingdom', '1989-10-10', 201129124, 'Non-Fiction', 'Information Technology', 'Not Applicable', 'E-Book', 2, 1),
(7, 'Brian W. Kernighan, Dennis M. Ritchie', 'The C Programming Language', 'Prentice-Hall', 'USA', '1988-02-03', 131103628, 'Non-Fiction', 'Information Technology', 'Not Applicable', 'Hard Copy', 1, 1),
(8, 'Suzanne Collins', 'The Ballad of Songbirds and Snakes', 'Scholastic', 'USA', '2020-09-01', 457987298, 'Fiction', 'Not Applicable', 'Young Adult', 'E-Book', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `book_request`
--

CREATE TABLE `book_request` (
  `request_id` int NOT NULL,
  `author` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `publisher` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_of_publication` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_publication` date NOT NULL,
  `ISBN` int NOT NULL,
  `type` enum('Fiction','Non-Fiction') COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` enum('Architecture','Built Environment','Business','Communication','Design','Education','Engineering','Health','Indigenous Studies','Information Technology','International Studies','Law','Science','Not Applicable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` enum('E-Book','Hard Copy') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `book_request`
--

INSERT INTO `book_request` (`request_id`, `author`, `title`, `publisher`, `place_of_publication`, `date_of_publication`, `ISBN`, `type`, `topic`, `format`) VALUES
(1, 'Orwell', '1984', 'Penguin Books', 'United Kingdom', '1949-06-08', 1234567812, 'Fiction', 'Not Applicable', 'E-Book');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `loan_id` int NOT NULL,
  `user_id` int NOT NULL,
  `book_id` int NOT NULL,
  `borrow_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date NOT NULL,
  `fee` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `firstname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_type` enum('Student','Staff','Admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `email`, `phonenumber`, `account_type`, `password`) VALUES
(1, 'Lisa', 'Ron', 'lisa.ron@email.com', '', 'Student', 'lisaron'),
(2, 'Jane', 'Smith', 'jane.smith@email.com', '', 'Admin', 'smith1'),
(3, 'John ', 'Smith', 'john.smith@email.com', '', 'Staff', 'password'),
(4, 'Hiro', 'Hamada', 'hiro.hamada@email.com', '', 'Student', 'mochi2'),
(5, 'Peter', 'Parker', 'peter.parker@email.com', '', 'Student', 'spiderman'),
(6, 'Arvin', 'Russell', 'arvin.russell@email.com', '', 'Staff', 'tdatt12'),
(7, 'Mike', 'Ross', 'mike.ross@email.com', '', 'Admin', 'ross10'),
(8, 'Gwen ', 'Stacy', 'gwen.stacy.email.com', '', 'Staff', 'password'),
(9, 'test', 'test', 'test@testing.com', '', 'Student', 'testing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `book_request`
--
ALTER TABLE `book_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`loan_id`),
  ADD KEY `book_id` (`book_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `book_request`
--
ALTER TABLE `book_request`
  MODIFY `request_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `loan_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `loans`
--
ALTER TABLE `loans`
  ADD CONSTRAINT `book_id` FOREIGN KEY (`book_id`) REFERENCES `books` (`book_id`),
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
