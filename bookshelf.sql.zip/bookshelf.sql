-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 02, 2020 at 11:43 AM
-- Server version: 8.0.21
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookshelf`
--
CREATE DATABASE IF NOT EXISTS `bookshelf` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `bookshelf`;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int NOT NULL,
  `author` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `publisher` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_of_publication` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_publication` date NOT NULL,
  `ISBN` bigint NOT NULL,
  `type` enum('Fiction','Non-Fiction') COLLATE utf8mb4_unicode_ci NOT NULL,
  `non_fiction_topic` enum('Architecture','Built Environment','Business','Communication','Design','Education','Engineering','Health','Indigenous Studies','Information Technology','International Studies','Law','News','Science','Not Applicable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fiction_topic` enum('Modern & Contemporary Fiction','Poetry & Drama','Romance','Crime','Classic Fiction','Fantasy','Adventure Fiction','Science Fiction','Historical Fiction','Horror & Paranormal Fiction','Graphic Novels','Young Adult','Manga','Dystopian','Picture Book','Not Applicable') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` enum('E-Book','Hard Copy') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `copies` int NOT NULL,
  `available` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `author`, `title`, `publisher`, `place_of_publication`, `date_of_publication`, `ISBN`, `type`, `non_fiction_topic`, `fiction_topic`, `format`, `copies`, `available`) VALUES
(1, 'Max Tegmark', 'Life 3.0: Being Human in the Age of Artificial Intelligence', 'Penguine UK', 'United Kingdom', '2018-07-05', 9780141981802, 'Non-Fiction', 'Engineering', 'Not Applicable', 'E-Book', 2, 1),
(2, 'Paul Kalanithi', 'When Breath Becomes Air', 'Random House UK', 'United Kingdom', '2017-01-03', 9781784701994, 'Non-Fiction', 'Health', 'Not Applicable', 'E-Book', 1, 1),
(3, 'The Secret Barrister', 'The Secret Barrister', 'Pan Macmillian UK', 'United Kingdom', '2019-04-04', 9781509841141, 'Non-Fiction', 'Law', 'Not Applicable', 'E-Book', 1, 1),
(4, 'Mathew Reilly', 'Scarecrow', 'St. Martin\'s Paperback', 'USA', '2003-10-03', 9780312930987, 'Fiction', 'Not Applicable', 'Crime', 'Hard Copy', 3, 3),
(5, 'James Dashner', 'The Fever Code', 'Chicken House', 'USA', '2016-09-27', 9781911075673, 'Fiction', 'Not Applicable', 'Young Adult', 'Hard Copy', 1, 1),
(6, 'Judy Kay, Bob Kummerfeld', 'C Programming in a Unix Environment', 'Addison Wesley', 'United Kingdom', '1989-10-10', 2011291243648, 'Non-Fiction', 'Information Technology', 'Not Applicable', 'E-Book', 2, 1),
(7, 'Brian W. Kernighan, Dennis M. Ritchie', 'The C Programming Language', 'Prentice-Hall', 'USA', '1988-02-03', 1311036281235, 'Non-Fiction', 'Information Technology', 'Not Applicable', 'Hard Copy', 1, 1),
(8, 'Suzanne Collins', 'The Ballad of Songbirds and Snakes', 'Scholastic', 'USA', '2020-09-01', 4579872983718, 'Fiction', 'Not Applicable', 'Young Adult', 'E-Book', 1, 0),
(9, 'Richard K. Morgan', 'Altered Carbon', 'Victor Gollancz Ltd.', 'United Kingdom', '2002-02-28', 9780575073628, 'Fiction', 'Not Applicable', 'Science Fiction', 'Hard Copy', 1, 1),
(10, 'Richard K. Morgan', 'Broken Angels', 'Hachette Australia', 'Australia', '2008-11-01', 9780575082253, 'Fiction', 'Not Applicable', 'Science Fiction', 'E-Book', 2, 2),
(11, 'Richard K. Morgan', 'Woken Furies', 'Hachette Australia', 'Australia', '2008-11-01', 9780575081277, 'Fiction', 'Not Applicable', 'Science Fiction', 'Hard Copy', 1, 1),
(12, 'James Dashner', 'Maze Runner: Death Cure', 'The Chicken House', 'USA', '2012-04-05', 9781908435200, 'Fiction', 'Not Applicable', 'Young Adult', 'Hard Copy', 1, 1),
(13, 'James Dasnher', 'Maze Runner: The Scorch Trials', 'The Chicken House', 'USA', '2011-08-04', 9781906427795, 'Fiction', 'Not Applicable', 'Young Adult', 'Hard Copy', 1, 1),
(14, 'Marian Wilkinson', 'The Carbon Club', 'Allen & Unwin', 'Australia', '2020-09-01', 9781760875992, 'Non-Fiction', 'Science', 'Not Applicable', 'Hard Copy', 1, 1),
(15, 'Fiona Killackey', 'Passion Purpose Profit', 'Hardie Grant Books', 'Australia', '2020-09-02', 9781743796184, 'Non-Fiction', 'Design', 'Not Applicable', 'E-Book', 3, 2),
(16, 'Ben Macintyre', 'Agent Sonya', 'Penguin UK', 'United Kingdom', '2020-09-15', 9780241408513, 'Non-Fiction', 'Law', 'Not Applicable', 'E-Book', 1, 1),
(17, 'Malcolm Gladwell', 'Blink', 'Penguin UK', 'United Kingdom', '2006-02-14', 9780141014593, 'Non-Fiction', 'Science', 'Not Applicable', 'E-Book', 1, 1),
(18, 'Daniel Kahnerman', 'Thinking, Fast and Slow', 'Penguin UK', 'United Kingdom', '2012-07-02', 9780141033570, 'Non-Fiction', 'Communication', 'Not Applicable', 'Hard Copy', 2, 2),
(19, 'Jane Harper', 'The Survivors', 'Pan Macmillian Australia', 'Australia', '2020-09-22', 9781760783935, 'Fiction', 'Not Applicable', 'Modern & Contemporary Fiction', 'Hard Copy', 2, 1),
(20, 'Stephen King', 'It', 'Hachette Australia', 'Australia', '2017-07-25', 9781473666948, 'Fiction', 'Not Applicable', 'Horror & Paranormal Fiction', 'E-Book', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `book_request`
--

CREATE TABLE `book_request` (
  `request_id` int NOT NULL,
  `author` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ISBN` bigint NOT NULL,
  `type` enum('Fiction','Non-Fiction') COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` enum('E-Book','Hard Copy') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `book_request`
--

INSERT INTO `book_request` (`request_id`, `author`, `title`, `ISBN`, `type`, `format`) VALUES
(1, 'George Orwell', '1984', 1234567812, 'Fiction', 'E-Book');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `loan_id` int NOT NULL,
  `user_id` int NOT NULL,
  `firstname` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_id` int NOT NULL,
  `book_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `borrow_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `due_date` date NOT NULL,
  `fee` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `loans`
--

INSERT INTO `loans` (`loan_id`, `user_id`, `firstname`, `lastname`, `book_id`, `book_title`, `book_author`, `borrow_date`, `due_date`, `fee`) VALUES
(2, 0, '', '', 0, '', '', '2020-09-28 14:00:00', '2020-10-13', 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `firstname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phonenumber` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_type` enum('Student','Staff','Admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `email`, `phonenumber`, `account_type`, `password`) VALUES
(1, 'Lisa', 'Ron', 'lisa.ron@email.com', '', 'Student', 'lisaron'),
(2, 'Jane', 'Smith', 'jane.smith@email.com', '', 'Admin', 'smith1'),
(3, 'John ', 'Smith', 'john.smith@email.com', '', 'Staff', 'password'),
(4, 'Hiro', 'Hamada', 'hiro.hamada@email.com', '', 'Student', 'mochi2'),
(5, 'Peter', 'Parker', 'peter.parker@email.com', '', 'Student', 'spiderman'),
(6, 'Arvin', 'Russell', 'arvin.russell@email.com', '', 'Staff', 'tdatt12'),
(7, 'Mike', 'Ross', 'mike.ross@email.com', '', 'Admin', 'ross10'),
(8, 'Gwen ', 'Stacy', 'gwen.stacy.email.com', '', 'Staff', 'password'),
(9, 'test', 'test', 'test@testing.com', '', 'Student', 'testing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `book_request`
--
ALTER TABLE `book_request`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `book_request`
--
ALTER TABLE `book_request`
  MODIFY `request_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `loan_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
